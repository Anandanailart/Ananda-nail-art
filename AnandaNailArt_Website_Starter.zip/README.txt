ANANDA NAIL ART WEBSITE STARTER

1. Open index.html locally to preview.
2. Replace placeholder gallery art with real customer photos when available.
3. Replace the WATCH THE VIDEO href="#" with your final video URL.
4. Replace the mailto booking link with your booking service URL once selected.
5. Publish the folder to GitHub Pages.
6. In GitHub Pages, set the custom domain to anandanailart.com.
7. Then update DNS at Spaceship.

This starter is responsive and uses no paid libraries or services.
